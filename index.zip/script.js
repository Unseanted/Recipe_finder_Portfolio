function navigateToApp() {
  window.location.href = 'http://recipefinder.infinityfreeapp.com/';
}
